let tasks = JSON.parse(localStorage.getItem("smartTodoTasks") || "[]");
let undoStack = JSON.parse(localStorage.getItem("smartTodoUndo") || "[]");
let nextId = Number(localStorage.getItem("smartTodoNextId") || "1");
let editingId = null;

const $ = id => document.getElementById(id);

function saveState(){
    localStorage.setItem("smartTodoTasks", JSON.stringify(tasks));
    localStorage.setItem("smartTodoUndo", JSON.stringify(undoStack.slice(-10)));
    localStorage.setItem("smartTodoNextId", String(nextId));
}

function snapshot(){
    return JSON.parse(JSON.stringify(tasks));
}

function remember(){
    undoStack.push(snapshot());
    if(undoStack.length > 10) undoStack.shift();
}

function message(text, error=false){
    $("message").textContent = text;
    $("message").className = error ? "message error" : "message";
    setTimeout(()=>{$("message").textContent=""}, 2200);
}

function clearForm(){
    $("taskTitle").value="";
    $("taskCategory").value="";
    $("taskDeadline").value="";
    $("taskDescription").value="";
    $("taskPriority").value="2";
    editingId=null;
    $("formHeading").textContent="Add a new task";
    $("saveTask").textContent="+ Add Task";
}

function addOrUpdate(){
    const title=$("taskTitle").value.trim();
    if(!title){ message("Please enter a task title.",true); $("taskTitle").focus(); return; }

    const data={
        title,
        category:$("taskCategory").value.trim() || "General",
        deadline:$("taskDeadline").value || "No deadline",
        priority:Number($("taskPriority").value),
        description:$("taskDescription").value.trim() || "No description"
    };

    remember();

    if(editingId!==null){
        const task=tasks.find(t=>t.id===editingId);
        Object.assign(task,data);
        message("Task updated successfully.");
    }else{
        tasks.push({id:nextId++,...data,completed:false,created:Date.now()});
        message("Task added successfully.");
    }

    saveState(); clearForm(); render();
}

function editTask(id){
    const t=tasks.find(x=>x.id===id);
    if(!t)return;
    editingId=id;
    $("taskTitle").value=t.title;
    $("taskCategory").value=t.category;
    $("taskDeadline").value=t.deadline==="No deadline"?"":t.deadline;
    $("taskDescription").value=t.description==="No description"?"":t.description;
    $("taskPriority").value=String(t.priority);
    $("formHeading").textContent="Update task";
    $("saveTask").textContent="Save Changes";
    window.scrollTo({top:250,behavior:"smooth"});
}

function completeTask(id){
    const t=tasks.find(x=>x.id===id); if(!t)return;
    remember(); t.completed=!t.completed; saveState(); render();
    message(t.completed?"Task completed.":"Task moved back to pending.");
}

function deleteTask(id){
    remember(); tasks=tasks.filter(t=>t.id!==id); saveState(); render(); message("Task deleted.");
}

function undo(){
    if(!undoStack.length){message("Nothing to undo.",true);return}
    tasks=undoStack.pop(); saveState(); render(); message("Last operation undone.");
}

function processQueue(){
    const t=tasks.find(x=>!x.completed);
    if(!t){message("Queue is empty.",true);return}
    remember(); t.completed=true; saveState(); render(); message("FIFO: first pending task completed.");
}

function processPriority(){
    const pending=tasks.filter(x=>!x.completed);
    if(!pending.length){message("Priority queue is empty.",true);return}
    pending.sort((a,b)=>b.priority-a.priority || a.id-b.id);
    const t=tasks.find(x=>x.id===pending[0].id);
    remember(); t.completed=true; saveState(); render(); message("Priority Queue: highest priority task completed.");
}

function priorityName(n){return n===3?"High":n===2?"Medium":"Low"}
function priorityClass(n){return priorityName(n).toLowerCase()}

function renderTask(t){
    return `<div class="task ${t.completed?"completed":""}">
        <div>
            <h3>${escapeHtml(t.title)}</h3>
            <p>Category: ${escapeHtml(t.category)}</p>
            <p>Deadline: ${escapeHtml(t.deadline)}</p>
            <p class="priority ${priorityClass(t.priority)}">Priority: ${priorityName(t.priority)}</p>
            <p>${escapeHtml(t.description)}</p>
        </div>
        <div class="task-actions">
            <button class="edit-btn" onclick="editTask(${t.id})">Edit</button>
            <button class="complete-btn" onclick="completeTask(${t.id})">${t.completed?"Undo":"Complete"}</button>
            <button class="delete-btn" onclick="deleteTask(${t.id})">Delete</button>
        </div>
    </div>`;
}

function escapeHtml(s){
    return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}

function render(){
    const q=$("search").value.toLowerCase().trim();
    let list=tasks.filter(t=>
        t.title.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q)
    );

    const sort=$("sortOption").value;
    if(sort==="priority") list.sort((a,b)=>b.priority-a.priority);
    else if(sort==="deadline") list.sort((a,b)=>(a.deadline==="No deadline"? "9999-99-99":a.deadline).localeCompare(b.deadline==="No deadline"?"9999-99-99":b.deadline));
    else if(sort==="title") list.sort((a,b)=>a.title.localeCompare(b.title));
    else list.sort((a,b)=>(b.created||b.id)-(a.created||a.id));

    const pending=list.filter(t=>!t.completed);
    const done=list.filter(t=>t.completed);

    $("pendingList").innerHTML=pending.length?pending.map(renderTask).join():`<div class="empty"><strong>No pending tasks</strong>Add a task above to start.</div>`;
    $("completedList").innerHTML=done.length?done.map(renderTask).join():`<div class="empty"><strong>No completed tasks</strong>Completed work will appear here.</div>`;

    const total=tasks.length, completed=tasks.filter(t=>t.completed).length;
    $("totalTasks").textContent=total;
    $("pendingTasks").textContent=total-completed;
    $("completedTasks").textContent=completed;
    $("highTasks").textContent=tasks.filter(t=>!t.completed && t.priority===3).length;
    $("pendingLabel").textContent=total-completed;
    $("doneLabel").textContent=completed;
}

$("saveTask").addEventListener("click",addOrUpdate);
$("clearForm").addEventListener("click",clearForm);
$("search").addEventListener("input",render);
$("sortOption").addEventListener("change",render);
$("undoBtn").addEventListener("click",undo);
$("queueBtn").addEventListener("click",processQueue);
$("priorityBtn").addEventListener("click",processPriority);

$("taskTitle").addEventListener("keydown",e=>{if(e.key==="Enter")addOrUpdate()});
render();
